import { useState, useMemo, useEffect } from "react";
import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import {
  Loader2,
  UtensilsCrossed,
  Globe,
  Phone,
  MapPin,
  Plus,
  Minus,
  ShoppingBag,
  X,
  ChevronDown,
  Filter,
  Leaf,
  Beef,
  WheatOff,
  Clock,
  CheckCircle2,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { type MenuItem } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";

const translations: Record<string, any> = {
  en: {
    loading: "Loading Menu...",
    notFound: "Restaurant Not Found",
    notFoundDesc:
      "We couldn't find the menu you're looking for. Please check the URL and try again.",
    openNow: "Open Now",
    closed: "Closed",
    reserve: "Reserve Table",
    website: "Website",
    totalBill: "Total Bill",
    clear: "Clear",
    callToOrder: "Call to Order",
    about: "About",
    ourLocation: "Our Location",
    poweredBy: "Powered by HAJDE HA",
    allCategories: "All Categories",
    allDietary: "All Dietary",
    vegetarian: "Vegetarian",
    vegan: "Vegan",
    glutenFree: "Gluten-Free",
  },
  al: {
    loading: "Duke ngarkuar menunë...",
    notFound: "Restoranti nuk u gjet",
    notFoundDesc:
      "Nuk mundëm ta gjenim menunë që kërkoni. Ju lutemi kontrolloni URL-në dhe provoni përsëri.",
    openNow: "Hapur tani",
    closed: "Mbyllur",
    reserve: "Rezervoni tavolinë",
    website: "Uebfaqja",
    totalBill: "Fatura totale",
    clear: "Pastro",
    callToOrder: "Telefono për porosi",
    about: "Rreth",
    ourLocation: "Lokacioni ynë",
    poweredBy: "Mundësuar nga HAJDE HA",
    allCategories: "Të gjitha kategoritë",
    allDietary: "Të gjitha dietat",
    vegetarian: "Vegjetariane",
    vegan: "Vegane",
    glutenFree: "Pa gluten",
  },
  mk: {
    loading: "Се вчитува менито...",
    notFound: "Ресторанот не е пронајден",
    notFoundDesc:
      "Не можевме да го најдеме менито што го барате. Ве молиме проверете ја URL-адресата и обидете се повторно.",
    openNow: "Отворено сега",
    closed: "Затворено",
    reserve: "Резервирај маса",
    website: "Веб-страница",
    totalBill: "Вкупна сметка",
    clear: "Исчисти",
    callToOrder: "Повикај за нарачка",
    about: "За",
    ourLocation: "Нашата локација",
    poweredBy: "Овозможено од HAJDE HA",
    allCategories: "Сите категории",
    allDietary: "Сите диети",
    vegetarian: "Вегетаријанско",
    vegan: "Веганско",
    glutenFree: "Без глутен",
  },
};

// Leaflet styles
const leafletStyles = `
  .leaflet-container {
    width: 100%;
    height: 100%;
    border-radius: 1rem;
    z-index: 10;
  }
`;

// Leaflet dynamic load component
function RestaurantMap({
  location,
  name,
  latitude,
  longitude,
}: {
  location: string;
  name: string;
  latitude?: string | null;
  longitude?: string | null;
}) {
  const [L, setL] = useState<any>(null);

  useEffect(() => {
    // Dynamically load leaflet
    const loadLeaflet = async () => {
      try {
        // @ts-ignore
        const leaflet = await import("leaflet");
        await import("leaflet/dist/leaflet.css");

        // Fix for default icons
        const DefaultIcon = leaflet.Icon.Default.prototype as any;
        delete DefaultIcon._getIconUrl;
        leaflet.Icon.Default.mergeOptions({
          iconRetinaUrl:
            "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
          iconUrl:
            "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
          shadowUrl:
            "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
        });
        setL(leaflet);
      } catch (err) {
        console.error("Failed to load leaflet", err);
      }
    };
    loadLeaflet();
  }, []);

  if (!L)
    return (
      <div className="w-full h-full bg-stone-100 animate-pulse rounded-2xl flex items-center justify-center text-stone-400">
        Loading Map...
      </div>
    );

  // Use stored coordinates if available, otherwise fallback to slug-based mock coords
  let position: [number, number] = [42.01, 20.97];

  if (
    latitude &&
    longitude &&
    !isNaN(parseFloat(latitude)) &&
    !isNaN(parseFloat(longitude))
  ) {
    position = [parseFloat(latitude), parseFloat(longitude)];
  } else {
    // Simple coordinates for Tetovë locations based on mock data fallback
    const coords: Record<string, [number, number]> = {
      "test-restaurant-tetove": [42.01, 20.97],
      "hajde-grill": [42.012, 20.975],
      "cafe-hajde": [42.008, 20.968],
    };

    const slug = name.toLowerCase().replace(/ /g, "-").replace(/ë/g, "e");
    position = coords[slug] || [42.01, 20.97];
  }

  return (
    <div className="w-full h-80 relative rounded-2xl overflow-hidden shadow-lg border border-stone-200">
      <style>{leafletStyles}</style>
      <div
        ref={(el) => {
          if (!el || !L || el.innerHTML) return;
          const map = L.map(el).setView(position, 15);
          L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
            attribution: "&copy; OpenStreetMap contributors",
          }).addTo(map);
          L.marker(position).addTo(map).bindPopup(name).openPopup();
        }}
        id="map"
        className="w-full h-full"
      />
    </div>
  );
}

// Helper to group items by category
const groupItems = (items: MenuItem[]) => {
  const groups: Record<string, MenuItem[]> = {};
  const order = ["Starters", "Mains", "Sides", "Desserts", "Drinks"];

  items.forEach((item) => {
    if (!item.active) return;
    if (!groups[item.category]) groups[item.category] = [];
    groups[item.category].push(item);
  });

  return Object.entries(groups).sort(([a], [b]) => {
    const idxA = order.indexOf(a);
    const idxB = order.indexOf(b);
    if (idxA !== -1 && idxB !== -1) return idxA - idxB;
    if (idxA !== -1) return -1;
    if (idxB !== -1) return 1;
    return a.localeCompare(b);
  });
};

function IsOpen(openingTime?: string, closingTime?: string) {
  if (!openingTime || !closingTime) return true;
  const d = new Date();
  const currentTime = `${d.getHours().toString().padStart(2, "0")}:${d.getMinutes().toString().padStart(2, "0")}`;
  return currentTime >= openingTime && currentTime <= closingTime;
}

export default function PublicMenu() {
  const { slug } = useParams<{ slug: string }>();
  const [lang] = useState<"en" | "al" | "mk">(() => {
    const saved = localStorage.getItem("hajdeha-lang");
    return (saved as any) || "en";
  });
  const t = translations[lang];

  const {
    data: restaurant,
    isLoading,
    error,
  } = useQuery({
    queryKey: [api.restaurants.getBySlug.path, slug],
    queryFn: async () => {
      const res = await fetch(`/api/restaurants/${slug}`);
      if (!res.ok) throw new Error("Restaurant not found");
      return res.json();
    },
    enabled: !!slug,
  });

  const [cart, setCart] = useState<Record<number, number>>({});

  const updateCart = (itemId: number, delta: number) => {
    setCart((prev) => {
      const current = prev[itemId] || 0;
      const next = Math.max(0, current + delta);
      if (next === 0) {
        const { [itemId]: _, ...rest } = prev;
        return rest;
      }
      return { ...prev, [itemId]: next };
    });
  };

  const cartTotal = useMemo(() => {
    if (!restaurant?.menuItems) return 0;
    return Object.entries(cart).reduce((total, [id, qty]) => {
      const item = restaurant.menuItems.find((i: any) => i.id === parseInt(id));
      if (!item) return total;
      const price = parseInt(item.price.replace(/[^0-9]/g, "")) || 0;
      return total + price * qty;
    }, 0);
  }, [cart, restaurant]);

  const [selectedCategory, setSelectedCategory] = useState<string>("All");

  const filteredItems = useMemo(() => {
    if (!restaurant?.menuItems) return [];
    return restaurant.menuItems.filter((item: MenuItem) => {
      if (!item.active) return false;

      const categoryMatch =
        selectedCategory === "All" || item.category === selectedCategory;

      return categoryMatch;
    });
  }, [restaurant?.menuItems, selectedCategory]);

  const categories = useMemo(() => {
    if (!restaurant?.menuItems) return [];
    const cats = new Set(restaurant.menuItems.map((i: any) => i.category));
    return Array.from(cats);
  }, [restaurant?.menuItems]);

  const cartCount = Object.values(cart).reduce((a, b) => a + b, 0);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-stone-50 via-white to-stone-50 flex flex-col items-center justify-center gap-6 text-stone-400">
        <div className="relative">
          <div className="absolute inset-0 bg-primary/20 rounded-full blur-2xl animate-pulse"></div>
          <Loader2 className="h-12 w-12 animate-spin text-primary relative" />
        </div>
        <p className="font-display text-lg animate-pulse text-stone-600">
          {t.loading}
        </p>
      </div>
    );
  }

  if (error || !restaurant) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-stone-50 via-white to-stone-50 flex flex-col items-center justify-center gap-6 p-6 text-center">
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-stone-100 to-stone-200 flex items-center justify-center shadow-lg">
          <UtensilsCrossed className="h-10 w-10 text-stone-400" />
        </div>
        <div>
          <h1 className="text-3xl font-display font-bold text-stone-800 mb-2">
            {t.notFound}
          </h1>
          <p className="text-stone-500 max-w-md mx-auto leading-relaxed">
            {t.notFoundDesc}
          </p>
        </div>
      </div>
    );
  }

  const groupedMenu = groupItems(filteredItems);
  const isOpen = IsOpen(restaurant.openingTime, restaurant.closingTime);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FDFBF7] via-white to-[#FDFBF7] pb-32">
      <Link href="/">
        <Button
          variant="ghost"
          className="fixed top-6 left-6 z-50 bg-white/90 backdrop-blur-lg hover:bg-white shadow-lg rounded-full h-11 w-11 p-0 border border-white/50 transition-all hover:scale-105"
        >
          <X className="h-5 w-5 text-stone-700" />
        </Button>
      </Link>

      {/* Restaurant Header */}
      <header className="relative bg-stone-900 overflow-hidden">
        {restaurant.photoUrl ? (
          <div className="absolute inset-0">
            <img
              src={restaurant.photoUrl}
              className="w-full h-full object-cover opacity-40"
              alt={restaurant.name}
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/90" />
          </div>
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-primary/10" />
        )}

        <div className="relative max-w-4xl mx-auto px-6 py-20 sm:py-28 text-center space-y-8 text-white">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
          >
            <div className="flex flex-col items-center gap-4">
              <h1 className="font-display font-bold text-5xl sm:text-7xl tracking-tight text-white drop-shadow-2xl leading-tight">
                {restaurant.name}
              </h1>
              <div
                className={`flex items-center gap-2 px-5 py-2 rounded-full text-sm font-bold uppercase tracking-widest shadow-lg ${isOpen ? "bg-emerald-500/30 text-emerald-300 border-2 border-emerald-400/50" : "bg-red-500/30 text-red-300 border-2 border-red-400/50"}`}
              >
                {isOpen ? (
                  <>
                    <CheckCircle2 className="h-4 w-4" />
                    {t.openNow}
                  </>
                ) : (
                  <>
                    <Clock className="h-4 w-4" />
                    {t.closed}
                  </>
                )}
              </div>
            </div>
          </motion.div>

          {restaurant.description && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.7 }}
              className="text-stone-100 text-lg sm:text-xl font-medium max-w-2xl mx-auto drop-shadow-lg leading-relaxed"
            >
              {restaurant.description}
            </motion.p>
          )}

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
            className="flex flex-wrap justify-center gap-4 pt-6"
          >
            {restaurant.website && (
              <a
                href={restaurant.website}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2.5 bg-white/10 hover:bg-white/20 backdrop-blur-lg px-6 py-3 rounded-full border-2 border-white/30 transition-all text-sm font-bold shadow-lg hover:scale-105"
              >
                <Globe className="h-4 w-4" />
                {t.website}
              </a>
            )}
            <a
              href={`tel:${restaurant.phoneNumber || "+38944123456"}`}
              className="flex items-center gap-2.5 bg-primary hover:bg-primary/90 px-8 py-3 rounded-full shadow-xl transition-all text-sm font-bold text-white hover:scale-105"
            >
              <Phone className="h-4 w-4" />
              {t.reserve}
            </a>
          </motion.div>

          {restaurant.openingTime && restaurant.closingTime && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
              className="flex items-center justify-center gap-2 text-stone-300 text-sm pt-4"
            >
              <Clock className="h-4 w-4" />
              <span className="font-medium">
                {restaurant.openingTime} - {restaurant.closingTime}
              </span>
            </motion.div>
          )}
        </div>
      </header>

      {/* Filters Section */}
      <div className="sticky top-0 z-40 bg-white/95 backdrop-blur-lg border-b border-stone-100 py-4 shadow-sm">
        <div className="max-w-4xl mx-auto px-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="outline"
                className="w-full justify-between bg-white rounded-xl h-12 border-stone-200 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-center gap-2.5">
                  <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                    <UtensilsCrossed className="h-4 w-4 text-primary" />
                  </div>
                  <span className="truncate font-semibold text-stone-900">
                    {selectedCategory === "All"
                      ? t.allCategories
                      : selectedCategory}
                  </span>
                </div>
                <ChevronDown className="h-4 w-4 text-stone-400" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-[--radix-dropdown-menu-trigger-width] rounded-xl bg-white border-stone-200 shadow-2xl z-[60]">
              <DropdownMenuItem
                onClick={() => setSelectedCategory("All")}
                className="hover:bg-stone-50 cursor-pointer py-3 px-4 font-semibold text-stone-700 focus:bg-stone-50 focus:text-stone-900 rounded-lg m-1"
              >
                {t.allCategories}
              </DropdownMenuItem>
              {categories.map((cat: any) => (
                <DropdownMenuItem
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className="hover:bg-stone-50 cursor-pointer py-3 px-4 font-medium text-stone-700 focus:bg-stone-50 focus:text-stone-900 rounded-lg m-1"
                >
                  {cat}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Menu Sections */}
      <main className="max-w-4xl mx-auto px-4 py-10 space-y-12">
        {groupedMenu.map(
          ([category, items]: [string, MenuItem[]], idx: number) => (
            <motion.section
              key={category}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="h-px flex-1 bg-gradient-to-r from-transparent to-stone-200" />
                <h2 className="font-display font-bold text-2xl text-primary px-6 py-2 bg-primary/5 rounded-full">
                  {category}
                </h2>
                <div className="h-px flex-1 bg-gradient-to-l from-transparent to-stone-200" />
              </div>
              <div className="grid gap-5">
                {items.map((item: MenuItem, itemIdx: number) => (
                  <motion.article
                    key={item.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: itemIdx * 0.05 }}
                    className="group flex gap-5 items-start bg-white p-6 rounded-2xl shadow-sm border border-stone-100 hover:shadow-lg hover:border-primary/20 transition-all duration-300"
                  >
                    {item.imageUrl && (
                      <img
                        src={item.imageUrl}
                        className="w-28 h-28 rounded-xl object-cover shadow-md flex-shrink-0 group-hover:scale-105 transition-transform duration-300"
                        alt={item.name}
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start gap-3 mb-2">
                        <h3 className="font-semibold text-stone-900 text-lg leading-tight">
                          {item.name}
                        </h3>
                        <span className="text-primary font-bold text-xl whitespace-nowrap">
                          {item.price}
                        </span>
                      </div>
                      <p className="text-sm text-stone-500 line-clamp-2 mb-3 leading-relaxed">
                        {item.description}
                      </p>

                      {/* Dietary Badges */}
                      {(item.isVegetarian ||
                        item.isVegan ||
                        item.isGlutenFree) && (
                        <div className="flex items-center gap-2 mb-3 flex-wrap">
                          {item.isVegetarian && (
                            <Badge
                              variant="secondary"
                              className="text-xs px-2.5 py-0.5 bg-emerald-100 text-emerald-700 border-emerald-200"
                            >
                              <Leaf className="h-3 w-3 mr-1" />
                              Vegetarian
                            </Badge>
                          )}
                          {item.isVegan && (
                            <Badge
                              variant="secondary"
                              className="text-xs px-2.5 py-0.5 bg-green-100 text-green-700 border-green-200"
                            >
                              <Leaf className="h-3 w-3 mr-1" />
                              Vegan
                            </Badge>
                          )}
                          {item.isGlutenFree && (
                            <Badge
                              variant="secondary"
                              className="text-xs px-2.5 py-0.5 bg-amber-100 text-amber-700 border-amber-200"
                            >
                              <WheatOff className="h-3 w-3 mr-1" />
                              Gluten-Free
                            </Badge>
                          )}
                        </div>
                      )}

                      {/* Calculator Controls */}
                      <div className="flex items-center gap-3 bg-stone-50 w-fit p-1.5 rounded-full border border-stone-200 shadow-sm">
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-9 w-9 rounded-full hover:bg-white shadow-sm transition-all hover:scale-110"
                          onClick={(e) => {
                            e.preventDefault();
                            updateCart(item.id, -1);
                          }}
                        >
                          <Minus className="h-4 w-4 text-stone-600" />
                        </Button>
                        <span className="font-bold w-8 text-center text-stone-900 text-lg">
                          {cart[item.id] || 0}
                        </span>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-9 w-9 rounded-full hover:bg-white shadow-sm transition-all hover:scale-110"
                          onClick={(e) => {
                            e.preventDefault();
                            updateCart(item.id, 1);
                          }}
                        >
                          <Plus className="h-4 w-4 text-stone-600" />
                        </Button>
                      </div>
                    </div>
                  </motion.article>
                ))}
              </div>
            </motion.section>
          ),
        )}

        {/* Restaurant Info Section under Menu */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="pt-16 border-t border-stone-200"
        >
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-stone-100 space-y-8">
            <div>
              <h2 className="font-display font-bold text-3xl text-stone-900 mb-4">
                {t.about} {restaurant.name}
              </h2>
              <p className="text-stone-600 leading-relaxed text-lg">
                {restaurant.description || "No description available."}
              </p>
            </div>

            {(restaurant.location || true) && (
              <div className="pt-8 border-t border-stone-100 space-y-5">
                <h3 className="font-semibold text-xl text-stone-900 mb-4 flex items-center gap-2.5">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <MapPin className="h-5 w-5 text-primary" />
                  </div>
                  {t.ourLocation}
                </h3>
                <RestaurantMap
                  location={restaurant.location || "Tetovë Center, 1200"}
                  name={restaurant.name}
                  latitude={restaurant.latitude}
                  longitude={restaurant.longitude}
                />
                <div className="flex items-start gap-3 bg-stone-50 p-4 rounded-xl border border-stone-100">
                  <MapPin className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <p className="text-stone-700 font-medium leading-relaxed">
                    {restaurant.location || "Tetovë Center, 1200"}
                  </p>
                </div>
              </div>
            )}
          </div>
        </motion.section>
      </main>

      {/* Calculator Summary Bar */}
      <AnimatePresence>
        {cartCount > 0 && (
          <motion.div
            initial={{ y: 120 }}
            animate={{ y: 0 }}
            exit={{ y: 120 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t-2 border-stone-200 shadow-[0_-8px_30px_rgba(0,0,0,0.12)] p-5 z-50"
          >
            <div className="max-w-4xl mx-auto flex items-center justify-between gap-4 flex-wrap sm:flex-nowrap">
              <div className="flex items-center gap-4">
                <div className="bg-primary text-primary-foreground p-3.5 rounded-xl shadow-lg">
                  <ShoppingBag className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider mb-0.5">
                    {t.totalBill}
                  </p>
                  <p className="text-3xl font-bold text-primary">
                    {cartTotal} DEN
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 flex-1 w-full sm:w-auto">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setCart({})}
                  className="text-stone-500 hover:text-stone-700 hover:bg-stone-100 rounded-xl"
                >
                  <X className="h-4 w-4 mr-2" />
                  {t.clear}
                </Button>

                <a
                  href={`tel:${restaurant.phoneNumber || "+38944123456"}`}
                  className="flex-1 sm:flex-none"
                >
                  <Button className="w-full rounded-xl bg-primary text-white hover:bg-primary/90 font-bold h-12 px-8 shadow-lg hover:shadow-xl transition-all">
                    <UtensilsCrossed className="h-4 w-4 mr-2" />
                    {t.callToOrder}
                  </Button>
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <footer className="py-12 text-center text-stone-400 text-sm space-y-3">
        {restaurant.location && (
          <div className="flex items-center justify-center gap-2 text-stone-500 mb-2">
            <MapPin className="h-4 w-4" />
            <span className="font-medium">{restaurant.location}</span>
          </div>
        )}
        <p className="text-stone-400">{t.poweredBy}</p>
      </footer>
    </div>
  );
}
