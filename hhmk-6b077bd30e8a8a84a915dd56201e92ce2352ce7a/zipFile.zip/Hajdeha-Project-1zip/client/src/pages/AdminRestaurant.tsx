import { useState, useEffect, useRef } from "react";
import { useParams, Link } from "wouter";
import { useRestaurant, useUpdateRestaurant } from "@/hooks/use-restaurants";
import {
  useCreateMenuItem,
  useUpdateMenuItem,
  useDeleteMenuItem,
} from "@/hooks/use-menu-items";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  ArrowLeft,
  Plus,
  Edit2,
  Trash2,
  Loader2,
  Image as ImageIcon,
  Globe,
  Phone,
  MapPin,
  Clock,
  Upload,
  X,
  Link as LinkIcon,
} from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  insertMenuItemSchema,
  type InsertMenuItem,
  type MenuItem,
} from "@shared/schema";

const CATEGORIES = ["Starters", "Mains", "Sides", "Desserts", "Drinks"];

// Image Upload Component
function ImageUpload({
  value,
  onChange,
  label,
}: {
  value: string;
  onChange: (url: string) => void;
  label: string;
}) {
  const [uploadMode, setUploadMode] = useState<"url" | "file">("url");
  const [preview, setPreview] = useState<string>(value);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setPreview(value);
  }, [value]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      alert("Please select an image file");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert("Image size should be less than 5MB");
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      setPreview(base64String);
      onChange(base64String);
    };
    reader.readAsDataURL(file);
  };

  const clearImage = () => {
    setPreview("");
    onChange("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div className="grid gap-2.5">
      <Label className="text-sm font-semibold">{label}</Label>

      <div className="flex gap-2 mb-2">
        <Button
          type="button"
          variant={uploadMode === "url" ? "default" : "outline"}
          size="sm"
          onClick={() => setUploadMode("url")}
          className="flex-1"
        >
          <LinkIcon className="h-4 w-4 mr-2" />
          URL
        </Button>
        <Button
          type="button"
          variant={uploadMode === "file" ? "default" : "outline"}
          size="sm"
          onClick={() => setUploadMode("file")}
          className="flex-1"
        >
          <Upload className="h-4 w-4 mr-2" />
          Upload
        </Button>
      </div>

      {uploadMode === "url" ? (
        <Input
          value={value}
          onChange={(e) => {
            onChange(e.target.value);
            setPreview(e.target.value);
          }}
          placeholder="https://..."
          className="h-10"
        />
      ) : (
        <div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
            id="file-upload"
          />
          <label htmlFor="file-upload">
            <div className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-muted/50 transition-colors">
              <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
              <p className="text-sm font-medium">Click to upload image</p>
              <p className="text-xs text-muted-foreground mt-1">
                PNG, JPG, GIF up to 5MB
              </p>
            </div>
          </label>
        </div>
      )}

      {preview && (
        <div className="relative mt-2">
          <img
            src={preview}
            alt="Preview"
            className="w-full h-48 object-cover rounded-lg border"
            onError={() => {
              if (uploadMode === "url") {
                setPreview("");
              }
            }}
          />
          <Button
            type="button"
            variant="destructive"
            size="icon"
            className="absolute top-2 right-2 h-8 w-8"
            onClick={clearImage}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  );
}

export default function AdminRestaurant() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id || "0");
  const { data: restaurant, isLoading } = useRestaurant(id);
  const { toast } = useToast();

  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-muted/20">
        <div className="text-center space-y-4">
          <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto" />
          <p className="text-sm text-muted-foreground">Loading restaurant...</p>
        </div>
      </div>
    );
  }

  if (!restaurant)
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-semibold">Restaurant not found</h2>
          <p className="text-muted-foreground">
            The restaurant you're looking for doesn't exist.
          </p>
        </div>
      </div>
    );

  return (
    <div className="min-h-screen bg-gradient-to-b from-muted/30 to-muted/10 pb-20">
      <header className="bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b sticky top-0 z-10 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/admin/dashboard">
              <Button variant="ghost" size="icon" className="hover:bg-muted">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <span className="text-xl font-bold text-primary">
                  {restaurant.name.charAt(0)}
                </span>
              </div>
              <div>
                <h1 className="font-display font-bold text-xl tracking-tight">
                  {restaurant.name}
                </h1>
                <p className="text-xs text-muted-foreground font-medium">
                  Menu Management
                </p>
              </div>
            </div>
          </div>
          <Button
            onClick={() => {
              setEditingItem(null);
              setIsItemModalOpen(true);
            }}
            className="shadow-sm"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Menu Item
          </Button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        <section>
          <RestaurantDetailsForm restaurant={restaurant} />
        </section>

        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-display font-bold tracking-tight">
                Menu Items
              </h2>
              <p className="text-sm text-muted-foreground mt-1">
                Manage your restaurant's offerings
              </p>
            </div>
            {restaurant.menuItems && restaurant.menuItems.length > 0 && (
              <div className="text-sm text-muted-foreground bg-muted/50 px-3 py-1.5 rounded-full">
                {restaurant.menuItems.length}{" "}
                {restaurant.menuItems.length === 1 ? "item" : "items"}
              </div>
            )}
          </div>

          <div className="grid gap-6">
            {restaurant.menuItems?.length === 0 ? (
              <div className="text-center py-16 bg-white rounded-2xl border-2 border-dashed">
                <div className="mx-auto w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center mb-4">
                  <ImageIcon className="h-8 w-8 text-muted-foreground/50" />
                </div>
                <h3 className="font-semibold text-lg mb-1">
                  No menu items yet
                </h3>
                <p className="text-muted-foreground text-sm mb-4">
                  Get started by adding your first dish
                </p>
                <Button onClick={() => setIsItemModalOpen(true)} size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add First Item
                </Button>
              </div>
            ) : (
              CATEGORIES.map((category) => {
                const items = restaurant.menuItems?.filter(
                  (item) => item.category === category,
                );
                if (!items?.length) return null;
                return (
                  <div key={category} className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="h-px flex-1 bg-border" />
                      <h3 className="font-semibold text-lg text-primary px-4 py-1 bg-primary/5 rounded-full">
                        {category}
                      </h3>
                      <div className="h-px flex-1 bg-border" />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                      {items.map((item) => (
                        <MenuItemCard
                          key={item.id}
                          item={item}
                          onEdit={() => {
                            setEditingItem(item);
                            setIsItemModalOpen(true);
                          }}
                        />
                      ))}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>
      </main>

      <MenuItemDialog
        open={isItemModalOpen}
        onOpenChange={setIsItemModalOpen}
        restaurantId={restaurant.id}
        initialData={editingItem}
      />
    </div>
  );
}

function RestaurantDetailsForm({ restaurant }: { restaurant: any }) {
  const { mutate: update, isPending } = useUpdateRestaurant();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);

  const [formData, setFormData] = useState({
    name: restaurant.name,
    description: restaurant.description || "",
    slug: restaurant.slug,
    photoUrl: restaurant.photoUrl || "",
    website: restaurant.website || "",
    phoneNumber: restaurant.phoneNumber || "",
    location: restaurant.location || "",
    openingTime: restaurant.openingTime || "08:00",
    closingTime: restaurant.closingTime || "22:00",
    active: restaurant.active ?? true,
    latitude: restaurant.latitude || "",
    longitude: restaurant.longitude || "",
  });

  useEffect(() => {
    setFormData({
      name: restaurant.name,
      description: restaurant.description || "",
      slug: restaurant.slug,
      photoUrl: restaurant.photoUrl || "",
      website: restaurant.website || "",
      phoneNumber: restaurant.phoneNumber || "",
      location: restaurant.location || "",
      openingTime: restaurant.openingTime || "08:00",
      closingTime: restaurant.closingTime || "22:00",
      active: restaurant.active ?? true,
      latitude: restaurant.latitude || "",
      longitude: restaurant.longitude || "",
    });
  }, [restaurant]);

  const handleSave = () => {
    update(
      { id: restaurant.id, ...formData },
      {
        onSuccess: () => {
          setIsEditing(false);
          toast({ title: "Updated successfully" });
        },
        onError: (err) => {
          toast({
            variant: "destructive",
            title: "Update failed",
            description: err.message,
          });
        },
      },
    );
  };

  if (!isEditing) {
    return (
      <div className="bg-white rounded-2xl p-8 border shadow-sm">
        <div className="space-y-6 w-full">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-semibold text-2xl font-display tracking-tight">
                Restaurant Profile
              </h3>
              <p className="text-sm text-muted-foreground mt-1">
                Manage your public information
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsEditing(true)}
              className="shadow-sm"
            >
              <Edit2 className="h-4 w-4 mr-2" />
              Edit Profile
            </Button>
          </div>

          <div className="pt-4 border-t">
            <div className="flex items-center gap-3 mb-6 pb-6 border-b">
              <Switch
                checked={restaurant.active ?? true}
                onCheckedChange={(checked) => {
                  update(
                    { id: restaurant.id, active: checked },
                    {
                      onSuccess: () =>
                        toast({
                          title: checked
                            ? "Restaurant enabled"
                            : "Restaurant disabled",
                        }),
                    },
                  );
                }}
              />
              <div>
                <span className="font-semibold text-sm">Restaurant Status</span>
                <p className="text-xs text-muted-foreground">
                  {restaurant.active
                    ? "Currently accepting orders"
                    : "Temporarily closed"}
                </p>
              </div>
              <div
                className={`ml-auto px-3 py-1 rounded-full text-xs font-medium ${restaurant.active ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"}`}
              >
                {restaurant.active ? "Active" : "Inactive"}
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="space-y-5">
                <div>
                  <span className="font-semibold text-xs text-muted-foreground uppercase tracking-wider block mb-1.5">
                    Restaurant Name
                  </span>
                  <p className="text-base font-medium">{restaurant.name}</p>
                </div>
                <div>
                  <span className="font-semibold text-xs text-muted-foreground uppercase tracking-wider block mb-1.5">
                    URL Slug
                  </span>
                  <p className="text-sm font-mono bg-muted/50 px-3 py-1.5 rounded-md inline-block">
                    {restaurant.slug}
                  </p>
                </div>
                <div>
                  <span className="font-semibold text-xs text-muted-foreground uppercase tracking-wider block mb-1.5">
                    Description
                  </span>
                  <p className="text-sm leading-relaxed">
                    {restaurant.description || "No description provided"}
                  </p>
                </div>
                <div>
                  <span className="font-semibold text-xs text-muted-foreground uppercase tracking-wider block mb-1.5">
                    Location
                  </span>
                  <div className="flex items-start gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                    <p className="text-sm">
                      {restaurant.location || "No location set"}
                    </p>
                  </div>
                </div>
                <div>
                  <span className="font-semibold text-xs text-muted-foreground uppercase tracking-wider block mb-1.5">
                    Working Hours
                  </span>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <p className="text-sm font-medium">
                      {restaurant.openingTime} - {restaurant.closingTime}
                    </p>
                  </div>
                </div>
                <div className="pt-3 flex flex-wrap gap-3">
                  {restaurant.website && (
                    <a
                      href={restaurant.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-sm text-primary hover:underline bg-primary/5 px-3 py-2 rounded-lg transition-colors"
                    >
                      <Globe className="h-4 w-4" />
                      <span className="font-medium">Visit Website</span>
                    </a>
                  )}
                  {restaurant.phoneNumber && (
                    <a
                      href={`tel:${restaurant.phoneNumber}`}
                      className="flex items-center gap-2 text-sm text-primary hover:underline bg-primary/5 px-3 py-2 rounded-lg transition-colors"
                    >
                      <Phone className="h-4 w-4" />
                      <span className="font-medium">
                        {restaurant.phoneNumber}
                      </span>
                    </a>
                  )}
                </div>
              </div>
              {restaurant.photoUrl && (
                <div className="rounded-xl overflow-hidden border shadow-sm h-64 lg:h-full">
                  <img
                    src={restaurant.photoUrl}
                    className="w-full h-full object-cover"
                    alt="Restaurant cover"
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl p-8 border shadow-sm space-y-6">
      <div>
        <h3 className="font-semibold text-2xl font-display tracking-tight">
          Edit Restaurant Profile
        </h3>
        <p className="text-sm text-muted-foreground mt-1">
          Update your restaurant information
        </p>
      </div>
      <div className="grid gap-6 lg:grid-cols-2 pt-4">
        <div className="space-y-5">
          <div className="grid gap-2.5">
            <Label className="text-sm font-semibold">Restaurant Name</Label>
            <Input
              value={formData.name}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, name: e.target.value }))
              }
              className="h-10"
            />
          </div>
          <div className="grid gap-2.5">
            <Label className="text-sm font-semibold">URL Slug</Label>
            <Input
              value={formData.slug}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, slug: e.target.value }))
              }
              className="h-10 font-mono"
            />
          </div>
          <div className="grid gap-2.5">
            <Label className="text-sm font-semibold">Phone Number</Label>
            <Input
              value={formData.phoneNumber}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  phoneNumber: e.target.value,
                }))
              }
              placeholder="+389 XX XXX XXX"
              className="h-10"
            />
          </div>
          <div className="grid gap-2.5">
            <Label className="text-sm font-semibold">Location Address</Label>
            <Input
              value={formData.location}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, location: e.target.value }))
              }
              placeholder="e.g. Rruga e Marshit, Tetovë"
              className="h-10"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2.5">
              <Label className="text-sm font-semibold">Latitude</Label>
              <Input
                value={formData.latitude}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, latitude: e.target.value }))
                }
                placeholder="e.g. 42.01"
                className="h-10"
              />
            </div>
            <div className="grid gap-2.5">
              <Label className="text-sm font-semibold">Longitude</Label>
              <Input
                value={formData.longitude}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    longitude: e.target.value,
                  }))
                }
                placeholder="e.g. 20.97"
                className="h-10"
              />
            </div>
          </div>
        </div>
        <div className="space-y-5">
          <div className="grid gap-2.5">
            <Label className="text-sm font-semibold">Website URL</Label>
            <Input
              value={formData.website}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, website: e.target.value }))
              }
              placeholder="https://yourwebsite.com"
              className="h-10"
            />
          </div>
          <ImageUpload
            value={formData.photoUrl}
            onChange={(url) =>
              setFormData((prev) => ({ ...prev, photoUrl: url }))
            }
            label="Cover Photo"
          />
          <div className="grid gap-2.5">
            <Label className="text-sm font-semibold">Description</Label>
            <Textarea
              value={formData.description}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  description: e.target.value,
                }))
              }
              className="h-[120px] resize-none"
              placeholder="Tell customers about your restaurant..."
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2.5">
              <Label className="text-sm font-semibold">Opening Time</Label>
              <Input
                type="time"
                value={formData.openingTime}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    openingTime: e.target.value,
                  }))
                }
                className="h-10"
              />
            </div>
            <div className="grid gap-2.5">
              <Label className="text-sm font-semibold">Closing Time</Label>
              <Input
                type="time"
                value={formData.closingTime}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    closingTime: e.target.value,
                  }))
                }
                className="h-10"
              />
            </div>
          </div>
        </div>
      </div>
      <div className="flex gap-3 justify-end pt-6 border-t">
        <Button variant="ghost" onClick={() => setIsEditing(false)}>
          Cancel
        </Button>
        <Button onClick={handleSave} disabled={isPending} className="shadow-sm">
          {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {isPending ? "Saving..." : "Save Changes"}
        </Button>
      </div>
    </div>
  );
}

function MenuItemCard({
  item,
  onEdit,
}: {
  item: MenuItem;
  onEdit: () => void;
}) {
  const { mutate: deleteItem } = useDeleteMenuItem();
  const { toast } = useToast();

  const handleDelete = () => {
    deleteItem(item.id, {
      onSuccess: () => toast({ title: "Item deleted" }),
      onError: () =>
        toast({ variant: "destructive", title: "Failed to delete" }),
    });
  };

  return (
    <div className="bg-white rounded-xl p-5 border shadow-sm hover:shadow-md transition-all duration-200 relative group hover:border-primary/20">
      <div className="flex gap-4">
        {item.imageUrl ? (
          <img
            src={item.imageUrl}
            alt={item.name}
            className="w-24 h-24 rounded-lg object-cover bg-muted shadow-sm flex-shrink-0"
          />
        ) : (
          <div className="w-24 h-24 rounded-lg bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center flex-shrink-0 border">
            <ImageIcon className="h-10 w-10 text-muted-foreground/30" />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-start gap-2 mb-2">
            <h4 className="font-semibold text-base truncate leading-tight">
              {item.name}
            </h4>
            <span className="font-bold text-primary whitespace-nowrap text-base">
              {item.price}
            </span>
          </div>
          <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed mb-3">
            {item.description}
          </p>
          <div className="flex items-center gap-2 flex-wrap">
            <div
              className={`text-xs px-2.5 py-1 rounded-full font-medium ${item.active ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"}`}
            >
              {item.active ? "Available" : "Unavailable"}
            </div>
            {item.isVegetarian && (
              <div className="text-xs px-2.5 py-1 rounded-full font-medium bg-emerald-100 text-emerald-700">
                Vegetarian
              </div>
            )}
            {item.isVegan && (
              <div className="text-xs px-2.5 py-1 rounded-full font-medium bg-green-100 text-green-700">
                Vegan
              </div>
            )}
            {item.isGlutenFree && (
              <div className="text-xs px-2.5 py-1 rounded-full font-medium bg-amber-100 text-amber-700">
                Gluten-Free
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="absolute top-3 right-3 flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity bg-white/95 backdrop-blur-sm rounded-lg p-1 shadow-md border">
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={onEdit}
        >
          <Edit2 className="h-4 w-4" />
        </Button>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Menu Item?</AlertDialogTitle>
              <AlertDialogDescription>
                This will permanently remove <strong>{item.name}</strong> from
                your menu. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDelete}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Delete Item
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}

function MenuItemDialog({
  open,
  onOpenChange,
  restaurantId,
  initialData,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  restaurantId: number;
  initialData: MenuItem | null;
}) {
  const { mutate: create, isPending: isCreating } = useCreateMenuItem();
  const { mutate: update, isPending: isUpdating } = useUpdateMenuItem();
  const { toast } = useToast();
  const isEditing = !!initialData;

  const form = useForm<InsertMenuItem>({
    resolver: zodResolver(insertMenuItemSchema),
    defaultValues: {
      name: "",
      description: "",
      price: "",
      category: "Mains",
      imageUrl: "",
      active: true,
      isVegetarian: false,
      isVegan: false,
      isGlutenFree: false,
      restaurantId,
    },
    values: initialData ? { ...initialData, restaurantId } : undefined,
  });

  const onSubmit = (data: InsertMenuItem) => {
    const onSuccess = () => {
      toast({
        title: isEditing
          ? "Item updated successfully"
          : "Item created successfully",
      });
      onOpenChange(false);
      form.reset();
    };

    const onError = (err: any) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: err.message,
      });
    };

    if (isEditing && initialData) {
      update({ id: initialData.id, ...data }, { onSuccess, onError });
    } else {
      create(data, { onSuccess, onError });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-xl font-display">
            {isEditing ? "Edit Menu Item" : "Add New Menu Item"}
          </DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Update the details of your menu item."
              : "Add a new dish to your restaurant menu."}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
          <div className="grid gap-5 py-2">
            <div className="grid gap-2.5">
              <Label htmlFor="name" className="text-sm font-semibold">
                Item Name
              </Label>
              <Input
                id="name"
                {...form.register("name")}
                placeholder="e.g. Classic Burger"
                className="h-10"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2.5">
                <Label htmlFor="price" className="text-sm font-semibold">
                  Price
                </Label>
                <Input
                  id="price"
                  {...form.register("price")}
                  placeholder="350 DEN"
                  className="h-10"
                />
              </div>
              <div className="grid gap-2.5">
                <Label htmlFor="category" className="text-sm font-semibold">
                  Category
                </Label>
                <Select
                  onValueChange={(val) => form.setValue("category", val)}
                  defaultValue={form.getValues("category") || "Mains"}
                >
                  <SelectTrigger className="h-10">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid gap-2.5">
              <Label htmlFor="description" className="text-sm font-semibold">
                Description
              </Label>
              <Textarea
                id="description"
                {...form.register("description")}
                placeholder="Describe the ingredients and preparation..."
                className="h-24 resize-none"
              />
            </div>

            <ImageUpload
              value={form.watch("imageUrl") || ""}
              onChange={(url) => form.setValue("imageUrl", url)}
              label="Item Image (Optional)"
            />

            <div className="space-y-4 pt-2 border-t">
              <div className="flex items-center justify-between py-2">
                <div className="space-y-0.5">
                  <Label htmlFor="active" className="text-sm font-semibold">
                    Availability
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Make this item available for ordering
                  </p>
                </div>
                <Switch
                  id="active"
                  checked={form.watch("active")}
                  onCheckedChange={(checked) =>
                    form.setValue("active", checked)
                  }
                />
              </div>

              <div className="space-y-0.5">
                <Label className="text-sm font-semibold block mb-3">
                  Dietary Information
                </Label>
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex items-center gap-2">
                    <Switch
                      id="isVegetarian"
                      checked={form.watch("isVegetarian")}
                      onCheckedChange={(checked) =>
                        form.setValue("isVegetarian", checked)
                      }
                    />
                    <Label
                      htmlFor="isVegetarian"
                      className="text-sm cursor-pointer"
                    >
                      Vegetarian
                    </Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      id="isVegan"
                      checked={form.watch("isVegan")}
                      onCheckedChange={(checked) =>
                        form.setValue("isVegan", checked)
                      }
                    />
                    <Label htmlFor="isVegan" className="text-sm cursor-pointer">
                      Vegan
                    </Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      id="isGlutenFree"
                      checked={form.watch("isGlutenFree")}
                      onCheckedChange={(checked) =>
                        form.setValue("isGlutenFree", checked)
                      }
                    />
                    <Label
                      htmlFor="isGlutenFree"
                      className="text-sm cursor-pointer"
                    >
                      Gluten-Free
                    </Label>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="ghost"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isCreating || isUpdating}
              className="shadow-sm"
            >
              {(isCreating || isUpdating) && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              {isEditing ? "Save Changes" : "Create Item"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
