import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { api } from "@shared/routes";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { 
  Utensils, Globe, Phone, Search, Clock, 
  MapPin, ChevronRight, Loader2, User
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const translations: Record<string, any> = {
  en: {
    hero: "The Digital Menu Platform of Tetovë.",
    subHero: "Browse menus and calculate your bill before you order.",
    searchPlaceholder: "Search for restaurants or dishes (e.g. Pizza, Burger)...",
    results: "Search Results",
    localRestaurants: "Local Restaurants",
    found: "Found",
    matches: "matches",
    explore: "Explore the taste of Tetovë",
    noResults: "No results matching your search.",
    noRestaurants: "No restaurants have joined HAJDE HA yet.",
    whyUs: "Why Choose HAJDE HA?",
    whyUsSub: "The modern way to experience dining in Tetovë. Simple, efficient, and contactless.",
    digitalMenus: "Digital Menus",
    digitalMenusDesc: "Access high-quality menus instantly from any smartphone. No physical menus needed.",
    billCalc: "Bill Calculator",
    billCalcDesc: "Know exactly what your meal will cost before you order. Calculate sums in Denars instantly.",
    eco: "Eco-Friendly",
    ecoDesc: "Reduce paper waste by switching to digital menus. Update your menu anytime without reprinting.",
    listRestaurant: "Want to list your restaurant?",
    joinPlatform: "Join the fastest growing digital menu platform in Tetovë. Help your customers browse faster and better.",
    emailUs: "Email Us",
    callSupport: "Call Support",
    ownerLogin: "Owner Login",
    open: "Open",
    closed: "Closed",
    poweredBy: "Powered by HAJDE HA",
    howToUse: "How to Use HAJDE HA?",
    step1: "Select a Restaurant",
    step1Desc: "Browse our curated list of the best local restaurants in Tetovë.",
    step2: "Explore the Menu",
    step2Desc: "See dishes with photos, detailed descriptions, and up-to-date prices.",
    step3: "Calculate Your Bill",
    step3Desc: "Add items to your virtual bill to see the total before you even order.",
    step4: "Enjoy Your Meal",
    step4Desc: "Visit the restaurant or call them directly to place your order with confidence."
  },
  al: {
    hero: "Platforma e Menusë Dixhitale e Tetovës.",
    subHero: "Shfletoni menutë dhe llogaritni faturën tuaj para se të porosisni.",
    searchPlaceholder: "Kërko për restorante ose pjata (p.sh. Pica, Burger)...",
    results: "Rezultatet e Kërkimit",
    localRestaurants: "Restorantet Lokale",
    found: "U gjetën",
    matches: "përputhje",
    explore: "Eksploroni shijen e Tetovës",
    noResults: "Nuk u gjet asnjë rezultat që përputhet me kërkimin tuaj.",
    noRestaurants: "Ende asnjë restorant nuk i është bashkuar HAJDE HA.",
    whyUs: "Pse të zgjidhni HAJDE HA?",
    whyUsSub: "Mënyra moderne për të përjetuar ngrënien në Tetovë. E thjeshtë, efikase dhe pa kontakt.",
    digitalMenus: "Menu Dixhitale",
    digitalMenusDesc: "Qasuni menjëherë në menu cilësore nga çdo smartphone. Nuk ka nevojë për menu fizike.",
    billCalc: "Llogaritësi i Faturës",
    billCalcDesc: "Dini saktësisht se sa do të kushtojë vakti juaj para se të porosisni. Llogaritni shumat në Denarë menjëherë.",
    eco: "Ekologjike",
    ecoDesc: "Reduktoni mbetjet e letrës duke kaluar në menu dixhitale. Përditësoni menunë tuaj në çdo kohë pa riprintim.",
    listRestaurant: "Dëshironi të listoni restorantin tuaj?",
    joinPlatform: "Bashkohuni me platformën e menusë dixhitale me rritjen më të shpejtë në Tetovë.",
    emailUs: "Na dërgoni email",
    callSupport: "Telefoni Mbështetjen",
    ownerLogin: "Hyrja e Pronarit",
    open: "Hapur",
    closed: "Mbyllur",
    poweredBy: "Mundësuar nga HAJDE HA",
    howToUse: "Si ta përdorni këtë platformë?",
    step1: "Zgjidhni një restorant",
    step1Desc: "Shfletoni listën tonë të restoranteve më të mira në Tetovë.",
    step2: "Shfletoni menunë",
    step2Desc: "Shikoni pjatat me foto, përshkrime dhe çmime të sakta.",
    step3: "Llogaritni faturën",
    step3Desc: "Shtoni pjatat në llogaritës për të parë shumën totale para se të porosisni.",
    step4: "Shijoni vaktin tuaj",
    step4Desc: "Vizitoni restorantin ose telefononi direkt për të bërë porosinë tuaj."
  },
  mk: {
    hero: "Дигитална платформа за мени во Тетово.",
    subHero: "Прелистувајте менија и пресметајте ја вашата сметка пред да нарачате.",
    searchPlaceholder: "Пребарајте ресторани или јадења (на пр. Пица, Бургер)...",
    results: "Резултати од пребарувањето",
    localRestaurants: "Локални ресторани",
    found: "Пронајдени",
    matches: "резултати",
    explore: "Истражете го вкусот на Тетово",
    noResults: "Нема резултати што одговараат на вашето пребарување.",
    noRestaurants: "Ниту еден ресторан сè уште не се приклучил на HAJDE HA.",
    whyUs: "Зошто да изберете HAJDE HA?",
    whyUsSub: "Модерен начин за јадење во Тетово. Едноставно, ефикасно и без контакт.",
    digitalMenus: "Дигитални менија",
    digitalMenusDesc: "Пристапете до квалитетни менија веднаш од кој било паметен телефон. Нема потреба од физички менија.",
    billCalc: "Калкулатор на сметки",
    billCalcDesc: "Знајте точно колку ќе чини вашиот оброк пред да нарачате. Пресметајте ги сумите во денари веднаш.",
    eco: "Еколошки",
    ecoDesc: "Намалете го отпадот од хартија со префрлање на дигитални менија. Ажурирајте го вашето мени во секое време без печатење.",
    listRestaurant: "Сакате да го наведете вашиот ресторан?",
    joinPlatform: "Придружете се на најбрзо растечката дигитална платформа за менија во Тетово.",
    emailUs: "Пишете ни",
    callSupport: "Повикајте поддршка",
    ownerLogin: "Најава за сопственик",
    open: "Отворено",
    closed: "Затворено",
    poweredBy: "Овозможено од HAJDE HA",
    howToUse: "Како да ја користите оваа платформа?",
    step1: "Изберете ресторан",
    step1Desc: "Прелистајте ја нашата листа на најдобри ресторани во Тетово.",
    step2: "Прелистајте го менито",
    step2Desc: "Погледнете ги јадењата со слики, описи и точни цени.",
    step3: "Пресметајте ја сметката",
    step3Desc: "Додајте јадења во калкулаторот за да го видите вкупниот износ пред да нарачате.",
    step4: "Уживајте во вашиот оброк",
    step4Desc: "Посетете го ресторанот или јавете се директно за да ја направите вашата нарачка."
  }
};

function IsOpen(openingTime?: string, closingTime?: string) {
  if (!openingTime || !closingTime) return true;
  const d = new Date();
  const currentTime = `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
  return currentTime >= openingTime && currentTime <= closingTime;
}

export default function Home() {
  const [lang, setLang] = useState<"en" | "al" | "mk">(() => {
    const saved = localStorage.getItem("hajdeha-lang");
    return (saved as any) || "en";
  });

  const t = translations[lang];

  const handleLangChange = (newLang: "en" | "al" | "mk") => {
    setLang(newLang);
    localStorage.setItem("hajdeha-lang", newLang);
  };

  const [searchTerm, setSearchTerm] = useState("");
  const { data: restaurantsData, isLoading } = useQuery({
    queryKey: [api.restaurants.listAll.path],
  });
  const restaurants = ((restaurantsData as any[]) || []).filter(r => r.active !== false);

  const filteredRestaurants = restaurants.filter((restaurant: any) => {
    const searchLower = searchTerm.toLowerCase();
    const nameMatch = restaurant.name.toLowerCase().includes(searchLower);
    const menuMatch = restaurant.menuItems?.some((item: any) => 
      item.name.toLowerCase().includes(searchLower) || 
      item.description.toLowerCase().includes(searchLower)
    );
    return nameMatch || menuMatch;
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="py-20 px-4 text-center bg-primary text-primary-foreground relative overflow-hidden">
        <div className="absolute top-4 right-4 z-20 flex gap-2">
          <div className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-1 flex gap-1">
            <Button 
              variant="ghost" 
              size="sm" 
              className={`h-8 px-2 text-[10px] font-bold ${lang === 'en' ? 'bg-white text-primary' : 'text-white'}`}
              onClick={() => handleLangChange('en')}
            >
              EN
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className={`h-8 px-2 text-[10px] font-bold ${lang === 'al' ? 'bg-white text-primary' : 'text-white'}`}
              onClick={() => handleLangChange('al')}
            >
              AL
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className={`h-8 px-2 text-[10px] font-bold ${lang === 'mk' ? 'bg-white text-primary' : 'text-white'}`}
              onClick={() => handleLangChange('mk')}
            >
              MK
            </Button>
          </div>
          <Link href="/auth/login">
            <Button size="icon" variant="outline" className="bg-white/10 border-white/20 hover:bg-white/20 text-white rounded-xl" title={t.ownerLogin}>
              <User className="h-5 w-5" />
            </Button>
          </Link>
        </div>
        <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1200&q=80')] bg-cover bg-center" />
        <div className="max-w-4xl mx-auto relative z-10">
          <Utensils className="w-16 h-16 mx-auto mb-6" />
          <h1 className="text-5xl font-bold tracking-tight sm:text-7xl mb-6 font-display">
            HAJDE HA
          </h1>
          <p className="text-xl opacity-90 font-medium max-w-2xl mx-auto">
            {t.hero} 
            <br />
            {t.subHero}
          </p>
          
          <div className="max-w-xl mx-auto mt-10 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-primary" />
            <Input 
              placeholder={t.searchPlaceholder} 
              className="pl-12 h-14 bg-white text-stone-900 rounded-2xl border-0 shadow-xl focus-visible:ring-2 focus-visible:ring-white"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              data-testid="input-search-restaurants"
            />
          </div>
        </div>
      </section>

      {/* Restaurant List */}
      <main className="max-w-6xl mx-auto py-16 px-4">
        <div className="flex justify-between items-end mb-10">
          <div>
            <h2 className="text-3xl font-display font-bold">
              {searchTerm ? t.results : t.localRestaurants}
            </h2>
            <p className="text-muted-foreground mt-2">
              {searchTerm ? `${t.found} ${filteredRestaurants.length} ${t.matches}` : t.explore}
            </p>
          </div>
        </div>
        
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse h-64 rounded-2xl" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredRestaurants.map((restaurant: any) => {
              const isOpen = IsOpen(restaurant.openingTime, restaurant.closingTime);
              return (
                <Link key={restaurant.id} href={`/restaurant/${restaurant.slug}`}>
                  <Card className="hover-elevate cursor-pointer h-full border-0 shadow-lg overflow-hidden group rounded-2xl flex flex-col relative">
                    <div className={`absolute top-4 left-4 z-20 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest backdrop-blur-md border ${isOpen ? 'bg-green-500/20 text-green-600 border-green-500/30' : 'bg-red-500/20 text-red-600 border-red-500/30'}`}>
                      {isOpen ? `● ${t.open}` : `○ ${t.closed}`}
                    </div>
                    {restaurant.photoUrl && (
                      <div className="h-48 overflow-hidden flex-shrink-0">
                        <img 
                          src={restaurant.photoUrl} 
                          alt={restaurant.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      </div>
                    )}
                    <CardHeader className="bg-white flex-1 flex flex-col">
                      <CardTitle className="font-display text-2xl group-hover:text-primary transition-colors">
                        {restaurant.name}
                      </CardTitle>
                      <CardDescription className="line-clamp-2 text-stone-500 mt-2 flex-1">
                        {restaurant.description || "No description available."}
                      </CardDescription>
                      
                      <div className="flex gap-4 mt-4 text-xs text-stone-400 font-medium">
                        {restaurant.website && (
                          <div className="flex items-center gap-1">
                            <Globe className="h-3 w-3" />
                            Website
                          </div>
                        )}
                        {restaurant.phoneNumber && (
                          <div className="flex items-center gap-1">
                            <Phone className="h-3 w-3" />
                            Phone
                          </div>
                        )}
                      </div>
                    </CardHeader>
                  </Card>
                </Link>
              );
            })}
          </div>
        )}

        {filteredRestaurants.length === 0 && !isLoading && (
          <div className="text-center py-20 bg-muted/30 rounded-3xl">
            <Utensils className="h-12 w-12 mx-auto text-muted-foreground/30 mb-4" />
            <p className="text-muted-foreground text-lg">
              {searchTerm ? t.noResults : t.noRestaurants}
            </p>
          </div>
        )}
      </main>

      {/* How to Use Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-display font-bold mb-4">{t.howToUse}</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="bg-white p-8 rounded-2xl border border-stone-100 shadow-sm space-y-4">
              <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center font-bold text-xl">1</div>
              <h3 className="text-xl font-bold font-display">{t.step1}</h3>
              <p className="text-stone-500 text-sm">{t.step1Desc}</p>
            </div>
            
            <div className="bg-white p-8 rounded-2xl border border-stone-100 shadow-sm space-y-4">
              <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center font-bold text-xl">2</div>
              <h3 className="text-xl font-bold font-display">{t.step2}</h3>
              <p className="text-stone-500 text-sm">{t.step2Desc}</p>
            </div>
            
            <div className="bg-white p-8 rounded-2xl border border-stone-100 shadow-sm space-y-4">
              <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center font-bold text-xl">3</div>
              <h3 className="text-xl font-bold font-display">{t.step3}</h3>
              <p className="text-stone-500 text-sm">{t.step3Desc}</p>
            </div>
            
            <div className="bg-white p-8 rounded-2xl border border-stone-100 shadow-sm space-y-4">
              <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center font-bold text-xl">4</div>
              <h3 className="text-xl font-bold font-display">{t.step4}</h3>
              <p className="text-stone-500 text-sm">{t.step4Desc}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Us Section */}
      <section className="bg-stone-50 py-20 px-4 border-y">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-display font-bold mb-4">{t.whyUs}</h2>
            <p className="text-stone-500 max-w-2xl mx-auto">{t.whyUsSub}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center space-y-4">
              <div className="bg-primary/10 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto text-primary">
                <Utensils className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold font-display">{t.digitalMenus}</h3>
              <p className="text-stone-500">{t.digitalMenusDesc}</p>
            </div>

            <div className="text-center space-y-4">
              <div className="bg-primary/10 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto text-primary">
                <div className="text-2xl font-bold">DEN</div>
              </div>
              <h3 className="text-xl font-bold font-display">{t.billCalc}</h3>
              <p className="text-stone-500">{t.billCalcDesc}</p>
            </div>

            <div className="text-center space-y-4">
              <div className="bg-primary/10 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto text-primary">
                <Globe className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold font-display">{t.eco}</h3>
              <p className="text-stone-500">{t.ecoDesc}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto bg-stone-900 rounded-3xl p-10 md:p-16 text-white text-center">
          <h2 className="text-3xl font-display font-bold mb-6">{t.listRestaurant}</h2>
          <p className="text-stone-400 text-lg mb-10 max-w-xl mx-auto">
            {t.joinPlatform}
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <a href="mailto:info@hajdeha.mk" className="flex items-center gap-3 bg-white/10 hover:bg-white/20 px-6 py-3 rounded-xl border border-white/10 transition-colors">
              <div className="bg-white/20 p-2 rounded-lg">
                <Globe className="h-5 w-5" />
              </div>
              <div className="text-left">
                <p className="text-[10px] text-stone-400 uppercase font-bold tracking-wider">{t.emailUs}</p>
                <p className="font-semibold">info@hajdeha.mk</p>
              </div>
            </a>
            <a href="tel:+38944123456" className="flex items-center gap-3 bg-white/10 hover:bg-white/20 px-6 py-3 rounded-xl border border-white/10 transition-colors">
              <div className="bg-white/20 p-2 rounded-lg">
                <Phone className="h-5 w-5" />
              </div>
              <div className="text-left">
                <p className="text-[10px] text-stone-400 uppercase font-bold tracking-wider">{t.callSupport}</p>
                <p className="font-semibold">+389 44 123 456</p>
              </div>
            </a>
          </div>
        </div>
      </section>
      
      <footer className="py-12 border-t text-center text-stone-400 text-sm">
        <p>© 2026 HAJDE HA - Tetovë Digital Menu Platform</p>
      </footer>
    </div>
  );
}
