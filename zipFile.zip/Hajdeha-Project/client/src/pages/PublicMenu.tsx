import { useState, useMemo, useEffect } from "react";
import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { 
  Loader2, UtensilsCrossed, Globe, Phone, MapPin,
  Plus, Minus, ShoppingBag, X, ChevronDown, Filter,
  Leaf, Beef, WheatOff
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { type MenuItem } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";

const translations: Record<string, any> = {
  en: {
    loading: "Loading Menu...",
    notFound: "Restaurant Not Found",
    notFoundDesc: "We couldn't find the menu you're looking for. Please check the URL and try again.",
    openNow: "Open Now",
    closed: "Closed",
    reserve: "Reserve Table",
    website: "Website",
    totalBill: "Total Bill",
    clear: "Clear",
    callToOrder: "Call to Order",
    about: "About",
    ourLocation: "Our Location",
    poweredBy: "Powered by HAJDE HA",
    allCategories: "All Categories",
    allDietary: "All Dietary",
    vegetarian: "Vegetarian",
    vegan: "Vegan",
    glutenFree: "Gluten-Free"
  },
  al: {
    loading: "Duke ngarkuar menunë...",
    notFound: "Restoranti nuk u gjet",
    notFoundDesc: "Nuk mundëm ta gjenim menunë që kërkoni. Ju lutemi kontrolloni URL-në dhe provoni përsëri.",
    openNow: "Hapur tani",
    closed: "Mbyllur",
    reserve: "Rezervoni tavolinë",
    website: "Uebfaqja",
    totalBill: "Fatura totale",
    clear: "Pastro",
    callToOrder: "Telefono për porosi",
    about: "Rreth",
    ourLocation: "Lokacioni ynë",
    poweredBy: "Mundësuar nga HAJDE HA",
    allCategories: "Të gjitha kategoritë",
    allDietary: "Të gjitha dietat",
    vegetarian: "Vegjetariane",
    vegan: "Vegane",
    glutenFree: "Pa gluten"
  },
  mk: {
    loading: "Се вчитава менито...",
    notFound: "Ресторанот не е пронајден",
    notFoundDesc: "Не можевме да го најдеме менито што го барате. Ве молиме проверете ја URL-адресата и обидете се повторно.",
    openNow: "Отворено сега",
    closed: "Затворено",
    reserve: "Резервирај маса",
    website: "Веб-страница",
    totalBill: "Вкупна сметка",
    clear: "Исчисти",
    callToOrder: "Повикај за нарачка",
    about: "За",
    ourLocation: "Нашата локација",
    poweredBy: "Овозможено од HAJDE HA",
    allCategories: "Сите категории",
    allDietary: "Сите диети",
    vegetarian: "Вегетаријанско",
    vegan: "Веганско",
    glutenFree: "Без глутен"
  }
};

// Leaflet styles
const leafletStyles = `
  .leaflet-container {
    width: 100%;
    height: 100%;
    border-radius: 1rem;
    z-index: 10;
  }
`;

// Leaflet dynamic load component
function RestaurantMap({ location, name, latitude, longitude }: { location: string, name: string, latitude?: string | null, longitude?: string | null }) {
  const [L, setL] = useState<any>(null);

  useEffect(() => {
    // Dynamically load leaflet
    const loadLeaflet = async () => {
      try {
        // @ts-ignore
        const leaflet = await import("leaflet");
        await import("leaflet/dist/leaflet.css");
        
        // Fix for default icons
        const DefaultIcon = leaflet.Icon.Default.prototype as any;
        delete DefaultIcon._getIconUrl;
        leaflet.Icon.Default.mergeOptions({
          iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
          iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
          shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
        });
        setL(leaflet);
      } catch (err) {
        console.error("Failed to load leaflet", err);
      }
    };
    loadLeaflet();
  }, []);

  if (!L) return <div className="w-full h-full bg-stone-100 animate-pulse rounded-2xl flex items-center justify-center text-stone-400">Loading Map...</div>;

  // Use stored coordinates if available, otherwise fallback to slug-based mock coords
  let position: [number, number] = [42.01, 20.97];
  
  if (latitude && longitude && !isNaN(parseFloat(latitude)) && !isNaN(parseFloat(longitude))) {
    position = [parseFloat(latitude), parseFloat(longitude)];
  } else {
    // Simple coordinates for Tetovë locations based on mock data fallback
    const coords: Record<string, [number, number]> = {
      "test-restaurant-tetove": [42.01, 20.97],
      "hajde-grill": [42.012, 20.975],
      "cafe-hajde": [42.008, 20.968]
    };

    const slug = name.toLowerCase().replace(/ /g, '-').replace(/ë/g, 'e');
    position = coords[slug] || [42.01, 20.97];
  }

  return (
    <div className="w-full h-64 relative rounded-2xl overflow-hidden shadow-inner border border-stone-200">
      <style>{leafletStyles}</style>
      <div 
        ref={(el) => {
          if (!el || !L || el.innerHTML) return;
          const map = L.map(el).setView(position, 15);
          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
          }).addTo(map);
          L.marker(position).addTo(map)
            .bindPopup(name)
            .openPopup();
        }}
        id="map" 
        className="w-full h-full"
      />
    </div>
  );
}

// Helper to group items by category
const groupItems = (items: MenuItem[]) => {
  const groups: Record<string, MenuItem[]> = {};
  const order = ["Starters", "Mains", "Sides", "Desserts", "Drinks"];
  
  items.forEach(item => {
    if (!item.active) return;
    if (!groups[item.category]) groups[item.category] = [];
    groups[item.category].push(item);
  });

  return Object.entries(groups).sort(([a], [b]) => {
    const idxA = order.indexOf(a);
    const idxB = order.indexOf(b);
    if (idxA !== -1 && idxB !== -1) return idxA - idxB;
    if (idxA !== -1) return -1;
    if (idxB !== -1) return 1;
    return a.localeCompare(b);
  });
};

function IsOpen(openingTime?: string, closingTime?: string) {
  if (!openingTime || !closingTime) return true;
  const d = new Date();
  const currentTime = `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
  return currentTime >= openingTime && currentTime <= closingTime;
}

export default function PublicMenu() {
  const { slug } = useParams<{ slug: string }>();
  const [lang] = useState<"en" | "al" | "mk">(() => {
    const saved = localStorage.getItem("hajdeha-lang");
    return (saved as any) || "en";
  });
  const t = translations[lang];

  const { data: restaurant, isLoading, error } = useQuery({
    queryKey: [api.restaurants.getBySlug.path, slug],
    queryFn: async () => {
      const res = await fetch(`/api/restaurants/${slug}`);
      if (!res.ok) throw new Error("Restaurant not found");
      return res.json();
    },
    enabled: !!slug,
  });

  const [cart, setCart] = useState<Record<number, number>>({});

  const updateCart = (itemId: number, delta: number) => {
    setCart(prev => {
      const current = prev[itemId] || 0;
      const next = Math.max(0, current + delta);
      if (next === 0) {
        const { [itemId]: _, ...rest } = prev;
        return rest;
      }
      return { ...prev, [itemId]: next };
    });
  };

  const cartTotal = useMemo(() => {
    if (!restaurant?.menuItems) return 0;
    return Object.entries(cart).reduce((total, [id, qty]) => {
      const item = restaurant.menuItems.find((i: any) => i.id === parseInt(id));
      if (!item) return total;
      const price = parseInt(item.price.replace(/[^0-9]/g, "")) || 0;
      return total + (price * qty);
    }, 0);
  }, [cart, restaurant]);

  const [selectedCategory, setSelectedCategory] = useState<string>("All");

  const filteredItems = useMemo(() => {
    if (!restaurant?.menuItems) return [];
    return restaurant.menuItems.filter((item: MenuItem) => {
      if (!item.active) return false;
      
      const categoryMatch = selectedCategory === "All" || item.category === selectedCategory;
        
      return categoryMatch;
    });
  }, [restaurant?.menuItems, selectedCategory]);

  const categories = useMemo(() => {
    if (!restaurant?.menuItems) return [];
    const cats = new Set(restaurant.menuItems.map((i: any) => i.category));
    return Array.from(cats);
  }, [restaurant?.menuItems]);

  const cartCount = Object.values(cart).reduce((a, b) => a + b, 0);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-stone-50 flex flex-col items-center justify-center gap-4 text-stone-400">
        <Loader2 className="h-8 w-8 animate-spin" />
        <p className="font-display animate-pulse">{t.loading}</p>
      </div>
    );
  }

  if (error || !restaurant) {
    return (
      <div className="min-h-screen bg-stone-50 flex flex-col items-center justify-center gap-4 p-6 text-center">
        <div className="w-16 h-16 rounded-full bg-stone-200 flex items-center justify-center">
          <UtensilsCrossed className="h-8 w-8 text-stone-400" />
        </div>
        <h1 className="text-2xl font-display font-bold text-stone-800">{t.notFound}</h1>
        <p className="text-stone-500 max-w-xs mx-auto">
          {t.notFoundDesc}
        </p>
      </div>
    );
  }

  const groupedMenu = groupItems(filteredItems);
  const isOpen = IsOpen(restaurant.openingTime, restaurant.closingTime);

  return (
    <div className="min-h-screen bg-[#FDFBF7] pb-32">
      <Link href="/">
        <Button variant="ghost" className="fixed top-4 left-4 z-50 bg-white/20 backdrop-blur-md hover:bg-white/40 rounded-full h-10 w-10 p-0">
          <X className="h-5 w-5 text-white" />
        </Button>
      </Link>

      {/* Restaurant Header */}
      <header className="relative bg-stone-900 overflow-hidden">
        {restaurant.photoUrl ? (
          <div className="absolute inset-0">
            <img 
              src={restaurant.photoUrl} 
              className="w-full h-full object-cover opacity-50" 
              alt={restaurant.name}
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/80" />
          </div>
        ) : (
          <div className="absolute inset-0 bg-primary/20" />
        )}
        
        <div className="relative max-w-3xl mx-auto px-6 py-16 sm:py-24 text-center space-y-6 text-white">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex flex-col items-center gap-3">
              <h1 className="font-display font-bold text-4xl sm:text-6xl tracking-tight text-white drop-shadow-2xl">
                {restaurant.name}
              </h1>
              <div className={`px-4 py-1 rounded-full text-sm font-bold uppercase tracking-widest ${isOpen ? 'bg-green-500/20 text-green-400 border border-green-500/30' : 'bg-red-500/20 text-red-400 border border-red-500/30'}`}>
                {isOpen ? `● ${t.openNow}` : `○ ${t.closed}`}
              </div>
            </div>
          </motion.div>
          
          {restaurant.description && (
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="text-stone-100 text-lg sm:text-xl font-medium max-w-xl mx-auto drop-shadow-md leading-relaxed"
            >
              {restaurant.description}
            </motion.p>
          )}
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5 }}
            className="flex flex-wrap justify-center gap-4 pt-4"
          >
            {restaurant.website && (
              <a href={restaurant.website} target="_blank" rel="noreferrer" className="flex items-center gap-2 bg-white/10 hover:bg-white/20 backdrop-blur-md px-4 py-2 rounded-full border border-white/20 transition-all text-sm font-semibold">
                <Globe className="h-4 w-4" />
                {t.website}
              </a>
            )}
            <a href={`tel:${restaurant.phoneNumber || "+38944123456"}`} className="flex items-center gap-2 bg-primary hover:bg-primary/90 px-6 py-2 rounded-full shadow-lg transition-all text-sm font-bold text-white">
              <Phone className="h-4 w-4" />
              {t.reserve}
            </a>
          </motion.div>
        </div>
      </header>

      {/* Filters Section */}
      <div className="sticky top-0 z-40 bg-[#FDFBF7] border-b border-stone-100 py-3 shadow-sm">
        <div className="max-w-3xl mx-auto px-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="w-full justify-between bg-white rounded-xl h-11 border-stone-200">
                <div className="flex items-center gap-2">
                  <UtensilsCrossed className="h-4 w-4 text-primary" />
                  <span className="truncate font-semibold text-stone-900">{selectedCategory === "All" ? t.allCategories : selectedCategory}</span>
                </div>
                <ChevronDown className="h-4 w-4 text-stone-400" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-[--radix-dropdown-menu-trigger-width] rounded-xl bg-white border-stone-200 shadow-xl z-[60]">
              <DropdownMenuItem 
                onClick={() => setSelectedCategory("All")}
                className="hover:bg-stone-50 cursor-pointer py-3 px-4 font-medium text-stone-700 focus:bg-stone-50 focus:text-stone-900"
              >
                {t.allCategories}
              </DropdownMenuItem>
              {categories.map((cat: any) => (
                <DropdownMenuItem 
                  key={cat} 
                  onClick={() => setSelectedCategory(cat)}
                  className="hover:bg-stone-50 cursor-pointer py-3 px-4 font-medium text-stone-700 focus:bg-stone-50 focus:text-stone-900"
                >
                  {cat}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Menu Sections */}
      <main className="max-w-3xl mx-auto px-4 py-8 space-y-12">
        {groupedMenu.map(([category, items]: [string, MenuItem[]], idx: number) => (
          <section key={category}>
            <h2 className="font-display font-bold text-2xl text-primary mb-6 border-b pb-2">{category}</h2>
            <div className="grid gap-6">
              {items.map((item: MenuItem) => (
                <article key={item.id} className="flex gap-4 items-start bg-white p-4 rounded-2xl shadow-sm border border-stone-50">
                  {item.imageUrl && (
                    <img src={item.imageUrl} className="w-24 h-24 rounded-xl object-cover shadow-sm flex-shrink-0" alt={item.name} />
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-baseline gap-2">
                      <h3 className="font-semibold text-stone-900 text-lg">{item.name}</h3>
                      <span className="text-primary font-bold text-lg whitespace-nowrap">{item.price}</span>
                    </div>
                    <p className="text-sm text-stone-500 line-clamp-2 mt-1 mb-2">{item.description}</p>
                    
                    {/* Calculator Controls */}
                    <div className="flex items-center gap-3 bg-stone-100/50 w-fit p-1 rounded-full border border-stone-200/50">
                      <Button 
                        size="icon" 
                        variant="ghost" 
                        className="h-8 w-8 rounded-full hover:bg-white shadow-sm"
                        onClick={(e) => {
                          e.preventDefault();
                          updateCart(item.id, -1);
                        }}
                      >
                        <Minus className="h-4 w-4 text-stone-600" />
                      </Button>
                      <span className="font-bold w-6 text-center text-stone-900">{cart[item.id] || 0}</span>
                      <Button 
                        size="icon" 
                        variant="ghost" 
                        className="h-8 w-8 rounded-full hover:bg-white shadow-sm"
                        onClick={(e) => {
                          e.preventDefault();
                          updateCart(item.id, 1);
                        }}
                      >
                        <Plus className="h-4 w-4 text-stone-600" />
                      </Button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </section>
        ))}

        {/* Restaurant Info Section under Menu */}
        <section className="pt-12 border-t border-stone-200">
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-stone-100 space-y-6">
            <div>
              <h2 className="font-display font-bold text-2xl text-stone-900 mb-4">{t.about} {restaurant.name}</h2>
              <p className="text-stone-600 leading-relaxed">
                {restaurant.description || "No description available."}
              </p>
              <div className="mt-4 flex items-center gap-2 text-stone-400 text-sm italic">
                <MapPin className="h-4 w-4" />
                Tetovë, Macedonia (Test Location)
              </div>
            </div>
            
            {(restaurant.location || true) && (
              <div className="pt-6 border-t border-stone-50 space-y-4">
                <h3 className="font-semibold text-stone-900 mb-3 flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-primary" />
                  {t.ourLocation}
                </h3>
                <RestaurantMap 
                  location={restaurant.location || "Tetovë Center, 1200"} 
                  name={restaurant.name} 
                  latitude={restaurant.latitude}
                  longitude={restaurant.longitude}
                />
                <p className="text-stone-600 font-medium">{restaurant.location || "Tetovë Center, 1200"}</p>
              </div>
            )}
          </div>
        </section>
      </main>

      {/* Calculator Summary Bar */}
      <AnimatePresence>
        {cartCount > 0 && (
          <motion.div 
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            exit={{ y: 100 }}
            className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-[0_-4px_10px_rgba(0,0,0,0.05)] p-4 z-50"
          >
            <div className="max-w-3xl mx-auto flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="bg-primary text-primary-foreground p-3 rounded-xl">
                  <ShoppingBag className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{t.totalBill}</p>
                  <p className="text-2xl font-bold text-primary">{cartTotal} DEN</p>
                </div>
              </div>
              
              <div className="flex flex-wrap items-center justify-end gap-2 flex-1">
                <Button variant="ghost" size="sm" onClick={() => setCart({})} className="text-stone-400 hover:text-stone-600">
                  <X className="h-4 w-4 mr-2" />
                  {t.clear}
                </Button>
                
                <a href={`tel:${restaurant.phoneNumber || "+38944123456"}`} className="flex-1 sm:flex-none">
                  <Button className="w-full rounded-xl bg-primary text-white hover:bg-primary/90 font-bold h-12 px-8">
                    <UtensilsCrossed className="h-4 w-4 mr-2" />
                    {t.callToOrder}
                  </Button>
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <footer className="py-12 text-center text-stone-400 text-sm">
        {restaurant.location && (
          <div className="flex items-center justify-center gap-2 text-stone-500 mb-4">
            <MapPin className="h-4 w-4" />
            <span className="font-medium">{restaurant.location}</span>
          </div>
        )}
        <p>{t.poweredBy}</p>
      </footer>
    </div>
  );
}
