import { useState, useEffect } from "react";
import { useParams, Link } from "wouter";
import { useRestaurant, useUpdateRestaurant } from "@/hooks/use-restaurants";
import { useCreateMenuItem, useUpdateMenuItem, useDeleteMenuItem } from "@/hooks/use-menu-items";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Plus, Edit2, Trash2, Loader2, Image as ImageIcon, Globe, Phone } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertMenuItemSchema, type InsertMenuItem, type MenuItem } from "@shared/schema";

const CATEGORIES = ["Starters", "Mains", "Sides", "Desserts", "Drinks"];

export default function AdminRestaurant() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id || "0");
  const { data: restaurant, isLoading } = useRestaurant(id);
  const { toast } = useToast();
  
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }

  if (!restaurant) return <div>Not found</div>;

  return (
    <div className="min-h-screen bg-muted/20 pb-20">
      <header className="bg-background border-b sticky top-0 z-10 shadow-sm">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/admin/dashboard">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="font-display font-bold text-xl">{restaurant.name}</h1>
              <p className="text-xs text-muted-foreground">Menu Management</p>
            </div>
          </div>
          <Button onClick={() => {
            setEditingItem(null);
            setIsItemModalOpen(true);
          }}>
            <Plus className="h-4 w-4 mr-2" />
            Add Item
          </Button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-8">
        <section>
          <RestaurantDetailsForm restaurant={restaurant} />
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-display font-bold">Menu Items</h2>
          
          <div className="grid gap-4">
            {restaurant.menuItems?.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-xl border border-dashed">
                <p className="text-muted-foreground">No items yet. Add your first dish!</p>
              </div>
            ) : (
              CATEGORIES.map(category => {
                const items = restaurant.menuItems?.filter(item => item.category === category);
                if (!items?.length) return null;
                return (
                  <div key={category} className="space-y-3">
                    <h3 className="font-semibold text-lg text-primary">{category}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {items.map(item => (
                        <MenuItemCard 
                          key={item.id} 
                          item={item} 
                          onEdit={() => {
                            setEditingItem(item);
                            setIsItemModalOpen(true);
                          }}
                        />
                      ))}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>
      </main>

      <MenuItemDialog 
        open={isItemModalOpen} 
        onOpenChange={setIsItemModalOpen}
        restaurantId={restaurant.id}
        initialData={editingItem}
      />
    </div>
  );
}

function RestaurantDetailsForm({ restaurant }: { restaurant: any }) {
  const { mutate: update, isPending } = useUpdateRestaurant();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  
  const [formData, setFormData] = useState({
    name: restaurant.name,
    description: restaurant.description || "",
    slug: restaurant.slug,
    photoUrl: restaurant.photoUrl || "",
    website: restaurant.website || "",
    phoneNumber: restaurant.phoneNumber || "",
    location: restaurant.location || "",
    openingTime: restaurant.openingTime || "08:00",
    closingTime: restaurant.closingTime || "22:00",
    active: restaurant.active ?? true,
    latitude: restaurant.latitude || "",
    longitude: restaurant.longitude || "",
  });

  useEffect(() => {
    setFormData({
      name: restaurant.name,
      description: restaurant.description || "",
      slug: restaurant.slug,
      photoUrl: restaurant.photoUrl || "",
      website: restaurant.website || "",
      phoneNumber: restaurant.phoneNumber || "",
      location: restaurant.location || "",
      openingTime: restaurant.openingTime || "08:00",
      closingTime: restaurant.closingTime || "22:00",
      active: restaurant.active ?? true,
      latitude: restaurant.latitude || "",
      longitude: restaurant.longitude || "",
    });
  }, [restaurant]);

  const handleSave = () => {
    update({ id: restaurant.id, ...formData }, {
      onSuccess: () => {
        setIsEditing(false);
        toast({ title: "Updated successfully" });
      },
      onError: (err) => {
        toast({ variant: "destructive", title: "Update failed", description: err.message });
      }
    });
  };

  if (!isEditing) {
    return (
      <div className="bg-white rounded-xl p-6 border shadow-sm flex justify-between items-start">
        <div className="space-y-4 w-full">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-semibold text-xl">Restaurant Details</h3>
              <p className="text-sm text-muted-foreground">Manage your public profile</p>
            </div>
            <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
              <Edit2 className="h-4 w-4 mr-2" />
              Edit Profile
            </Button>
          </div>
          
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-2 mb-2">
                <Switch 
                  checked={restaurant.active ?? true} 
                  onCheckedChange={(checked) => {
                    update({ id: restaurant.id, active: checked }, {
                      onSuccess: () => toast({ title: checked ? "Restaurant enabled" : "Restaurant disabled" })
                    });
                  }}
                />
                <span className="font-bold text-[10px] uppercase tracking-wider">Restaurant Status: {restaurant.active ? "Active" : "Disabled"}</span>
              </div>
              <p><span className="font-semibold text-stone-400 uppercase text-[10px] tracking-wider block">Restaurant Name</span> {restaurant.name}</p>
              <p><span className="font-semibold text-stone-400 uppercase text-[10px] tracking-wider block">URL Slug</span> {restaurant.slug}</p>
              <p><span className="font-semibold text-stone-400 uppercase text-[10px] tracking-wider block">Description</span> {restaurant.description || "No description"}</p>
              <p><span className="font-semibold text-stone-400 uppercase text-[10px] tracking-wider block">Location</span> {restaurant.location || "No location set"}</p>
              <p><span className="font-semibold text-stone-400 uppercase text-[10px] tracking-wider block">Working Hours</span> {restaurant.openingTime} - {restaurant.closingTime}</p>
              <p><span className="font-semibold text-stone-400 uppercase text-[10px] tracking-wider block">Photo URL</span> <span className="truncate block max-w-xs">{restaurant.photoUrl || "No photo set"}</span></p>
              <div className="pt-2 flex flex-wrap gap-4">
                {restaurant.website && (
                  <div className="flex items-center gap-1.5 text-primary">
                    <Globe className="h-4 w-4" />
                    <span className="font-medium">Website linked</span>
                  </div>
                )}
                {restaurant.phoneNumber && (
                  <div className="flex items-center gap-1.5 text-primary">
                    <Phone className="h-4 w-4" />
                    <span className="font-medium">{restaurant.phoneNumber}</span>
                  </div>
                )}
              </div>
            </div>
            {restaurant.photoUrl && (
              <div className="rounded-xl overflow-hidden border h-32">
                <img src={restaurant.photoUrl} className="w-full h-full object-cover" alt="Restaurant cover" />
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl p-6 border shadow-sm space-y-6">
      <h3 className="font-semibold text-lg">Edit Restaurant Profile</h3>
      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-4">
          <div className="grid gap-2">
            <Label>Name</Label>
            <Input 
              value={formData.name} 
              onChange={e => setFormData(prev => ({...prev, name: e.target.value}))} 
            />
          </div>
          <div className="grid gap-2">
            <Label>URL Slug</Label>
            <Input 
              value={formData.slug} 
              onChange={e => setFormData(prev => ({...prev, slug: e.target.value}))} 
            />
          </div>
          <div className="grid gap-2">
            <Label>Phone Number</Label>
            <Input 
              value={formData.phoneNumber} 
              onChange={e => setFormData(prev => ({...prev, phoneNumber: e.target.value}))} 
            />
          </div>
          <div className="grid gap-2">
            <Label>Location Address</Label>
            <Input 
              value={formData.location} 
              onChange={e => setFormData(prev => ({...prev, location: e.target.value}))} 
              placeholder="e.g. Rruga e Marshit, Tetovë"
            />
          </div>
        </div>
        <div className="space-y-4">
          <div className="grid gap-2">
            <Label>Website URL</Label>
            <Input 
              value={formData.website} 
              onChange={e => setFormData(prev => ({...prev, website: e.target.value}))} 
            />
          </div>
          <div className="grid gap-2">
            <Label>Photo URL (Cover Image)</Label>
            <Input 
              value={formData.photoUrl} 
              onChange={e => setFormData(prev => ({...prev, photoUrl: e.target.value}))} 
            />
          </div>
          <div className="grid gap-2">
            <Label>Description</Label>
            <Textarea 
              value={formData.description} 
              onChange={e => setFormData(prev => ({...prev, description: e.target.value}))} 
              className="h-[100px]"
            />
          </div>
            <div className="grid grid-cols-2 gap-4 pt-2">
            <div className="grid gap-2">
              <Label>Latitude</Label>
              <Input 
                value={formData.latitude} 
                onChange={e => setFormData(prev => ({...prev, latitude: e.target.value}))} 
                placeholder="e.g. 42.01"
              />
            </div>
            <div className="grid gap-2">
              <Label>Longitude</Label>
              <Input 
                value={formData.longitude} 
                onChange={e => setFormData(prev => ({...prev, longitude: e.target.value}))} 
                placeholder="e.g. 20.97"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 pt-2">
            <div className="grid gap-2">
              <Label>Opening Time</Label>
              <Input 
                type="time"
                value={formData.openingTime} 
                onChange={e => setFormData(prev => ({...prev, openingTime: e.target.value}))} 
              />
            </div>
            <div className="grid gap-2">
              <Label>Closing Time</Label>
              <Input 
                type="time"
                value={formData.closingTime} 
                onChange={e => setFormData(prev => ({...prev, closingTime: e.target.value}))} 
              />
            </div>
          </div>
        </div>
      </div>
      <div className="flex gap-2 justify-end pt-4 border-t">
        <Button variant="ghost" onClick={() => setIsEditing(false)}>Cancel</Button>
        <Button onClick={handleSave} disabled={isPending}>
          {isPending ? "Saving..." : "Save Changes"}
        </Button>
      </div>
    </div>
  );
}

function MenuItemCard({ item, onEdit }: { item: MenuItem, onEdit: () => void }) {
  const { mutate: deleteItem } = useDeleteMenuItem();
  const { toast } = useToast();

  const handleDelete = () => {
    deleteItem(item.id, {
      onSuccess: () => toast({ title: "Item deleted" }),
      onError: () => toast({ variant: "destructive", title: "Failed to delete" })
    });
  };

  return (
    <div className="bg-white rounded-xl p-4 border shadow-sm hover:shadow-md transition-shadow relative group">
      <div className="flex gap-4">
        {item.imageUrl ? (
          <img 
            src={item.imageUrl} 
            alt={item.name} 
            className="w-20 h-20 rounded-lg object-cover bg-muted"
          />
        ) : (
          <div className="w-20 h-20 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
            <ImageIcon className="h-8 w-8 text-muted-foreground/30" />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-start">
            <h4 className="font-medium truncate pr-2">{item.name}</h4>
            <span className="font-semibold text-primary">{item.price}</span>
          </div>
          <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
            {item.description}
          </p>
          <div className="flex items-center gap-2 mt-3">
            <div className={`text-xs px-2 py-0.5 rounded-full ${item.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>
              {item.active ? 'Active' : 'Inactive'}
            </div>
          </div>
        </div>
      </div>
      
      <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity bg-white/90 rounded-lg p-1 shadow-sm border">
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onEdit}>
          <Edit2 className="h-3.5 w-3.5" />
        </Button>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive hover:bg-destructive/10">
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Item?</AlertDialogTitle>
              <AlertDialogDescription>
                This will remove <strong>{item.name}</strong> from your menu permanently.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}

function MenuItemDialog({ 
  open, 
  onOpenChange, 
  restaurantId, 
  initialData 
}: { 
  open: boolean;
  onOpenChange: (open: boolean) => void;
  restaurantId: number;
  initialData: MenuItem | null;
}) {
  const { mutate: create, isPending: isCreating } = useCreateMenuItem();
  const { mutate: update, isPending: isUpdating } = useUpdateMenuItem();
  const { toast } = useToast();
  const isEditing = !!initialData;

  const form = useForm<InsertMenuItem>({
    resolver: zodResolver(insertMenuItemSchema),
    defaultValues: {
      name: "",
      description: "",
      price: "",
      category: "Mains",
      imageUrl: "",
      active: true,
      isVegetarian: false,
      isVegan: false,
      isGlutenFree: false,
      restaurantId,
    },
    values: initialData ? { ...initialData, restaurantId } : undefined,
  });

  const onSubmit = (data: InsertMenuItem) => {
    const onSuccess = () => {
      toast({ title: isEditing ? "Item updated" : "Item created" });
      onOpenChange(false);
      form.reset();
    };

    const onError = (err: any) => {
      toast({ variant: "destructive", title: "Error", description: err.message });
    };

    if (isEditing && initialData) {
      update({ id: initialData.id, ...data }, { onSuccess, onError });
    } else {
      create(data, { onSuccess, onError });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Menu Item" : "Add New Item"}</DialogTitle>
          <DialogDescription>
            {isEditing ? "Make changes to your item here." : "Add a new dish to your menu."}
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid gap-4 py-2">
            <div className="grid gap-2">
              <Label htmlFor="name">Name</Label>
              <Input id="name" {...form.register("name")} placeholder="e.g. Classic Burger" />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="price">Price (e.g. 350 DEN)</Label>
                <Input id="price" {...form.register("price")} placeholder="350 DEN" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="category">Category</Label>
                <Select 
                  onValueChange={(val) => form.setValue("category", val)} 
                  defaultValue={form.getValues("category") || "Mains"}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="description">Description</Label>
              <Textarea 
                id="description" 
                {...form.register("description")} 
                placeholder="Ingredients..." 
                className="h-20"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="imageUrl">Image URL (Optional)</Label>
              <Input id="imageUrl" {...form.register("imageUrl")} placeholder="https://..." />
            </div>

            <div className="flex flex-wrap gap-4 pt-2">
              <div className="flex items-center gap-2">
                <Switch 
                  id="active" 
                  checked={form.watch("active")} 
                  onCheckedChange={(checked) => form.setValue("active", checked)} 
                />
                <Label htmlFor="active">Available (Active)</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch 
                  id="isVegetarian" 
                  checked={form.watch("isVegetarian")} 
                  onCheckedChange={(checked) => form.setValue("isVegetarian", checked)} 
                />
                <Label htmlFor="isVegetarian">Vegetarian</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch 
                  id="isVegan" 
                  checked={form.watch("isVegan")} 
                  onCheckedChange={(checked) => form.setValue("isVegan", checked)} 
                />
                <Label htmlFor="isVegan">Vegan</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch 
                  id="isGlutenFree" 
                  checked={form.watch("isGlutenFree")} 
                  onCheckedChange={(checked) => form.setValue("isGlutenFree", checked)} 
                />
                <Label htmlFor="isGlutenFree">Gluten-Free</Label>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button type="submit" disabled={isCreating || isUpdating}>
              {(isCreating || isUpdating) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isEditing ? "Save Changes" : "Create Item"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
